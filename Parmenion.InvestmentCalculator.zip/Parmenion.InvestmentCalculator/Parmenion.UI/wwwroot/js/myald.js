var serviceUrl = "http://localhost:44310";



$(function () {

    function buildQuoteRequestUrl() {
        var lsInvestment = $("#lsInvestment").val();
        var mInvestment = $("#mInvestment").val();
        var timescale = $("#timescale").val();
        var riskLevel = $("#riskLevel").val();

        return "/Investment?lumpsum=" + lsInvestment + "&monthlyInvestment=" + mInvestment + "&timescale=" + timescale + "&riskLevel=" + riskLevel;
    }

    function renderQuote(quoteData) {
        debugger;
        $("#quoteId").text(quoteData.QuoteId);
        $("#quoteVehiclePrice").text(quoteData.VehicleRetailPrice);
        $("#quoteDeposit").text(quoteData.DepositAmount);
        $("#quoteApr").text(quoteData.Apr);
        $("#quoteMonthlyPayment").text(quoteData.MonthlyPayment);
        $("#quoteFinalPayment").text(quoteData.FinalPayment);
        $("#quoteTotalInterest").text(quoteData.TotalInterestPayable);
        $("#quoteTotalPayable").text(quoteData.TotalAmountPayable);
    }


    $("#getInvestment").click(function () {

        var requestUrl = buildQuoteRequestUrl();

        jQuery.ajax({
            url: serviceUrl + requestUrl,
            type: "GET",
            dataType: "json",
            contentType: "application/json; charset=utf-8",
            success: function (data) {
                renderQuote(data);
            }
        });

    });
});