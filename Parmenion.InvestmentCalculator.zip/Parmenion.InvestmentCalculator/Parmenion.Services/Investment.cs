using System;

namespace Parmenion.Services
{
    public class Investment
    {
        public int Year { get; set; }

        public double Amount { get; set; }
    }
}