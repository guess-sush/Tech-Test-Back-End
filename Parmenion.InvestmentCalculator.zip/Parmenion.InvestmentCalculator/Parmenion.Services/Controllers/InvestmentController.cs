﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Parmenion.Services.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class InvestmentController : ControllerBase
    {
        private readonly ILogger<InvestmentController> _logger;

        public InvestmentController(ILogger<InvestmentController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IEnumerable<Investment> Get(int lumpsum, int monthlyInvestment, int timescale, int riskLevel)
        {
            var growthRate = 1;
            switch (riskLevel)
            {
                case 1:
                    growthRate = 3;
                    break;
                case 2:
                    growthRate = 5;
                    break;
                case 3:
                    growthRate = 7;
                    break;
            }

            //monthlyInvestment = lumpsum + monthlyInvestment;

            return Enumerable.Range(1, timescale).Select(year => new Investment
            {
                Year = year,
                Amount = monthlyInvestment * Math.Pow((1 + growthRate), (year))
            }).ToArray();
        }
    }
}
